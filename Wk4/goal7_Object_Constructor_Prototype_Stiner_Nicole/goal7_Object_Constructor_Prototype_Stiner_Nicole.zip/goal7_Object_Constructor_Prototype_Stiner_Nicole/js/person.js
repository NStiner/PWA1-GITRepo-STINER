/*
 Nicole Stiner
 PWA1: Goal 7:  Course Material 7 (more.Objects - Constructors - Prototypes)
 03/24/2015
 ===================================================================
 PSUEDOCODE:

1. Start the function by making persons globally visable.
2. Adding four jobs and three actions for "persons" ending the first function
3. Starting second function creating person, action, job row
4. Set random job for person
5. Set random action for person
6. Arranging the actions to change through them randomly ever second
 */

(function(){

})(); //end of wrapper
